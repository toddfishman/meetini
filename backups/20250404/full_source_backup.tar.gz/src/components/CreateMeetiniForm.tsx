import React, { useState, useEffect } from 'react';
import { isContactPickerSupported, selectContacts } from '@/lib/contacts';
import { CircularProgress, Alert } from '@mui/material';
import { useSession } from 'next-auth/react';

declare global {
  interface Window {
    recognition: any;
    webkitSpeechRecognition: any;
  }
}

interface CreateMeetiniFormProps {
  isOpen: boolean;
  onClose: () => void;
  onSuccess: () => void;
  initialPrompt?: string | null;
  mode?: 'ai' | 'manual';
}

interface Contact {
  type: 'email' | 'phone';
  value: string;
  name?: string;
}

interface PickedContact {
  email?: string;
  phoneNumber?: string;
  name?: string;
}

type ContactResult = { type: 'email'; value: string; name?: string } | { type: 'phone'; value: string; name?: string };

interface FormData {
  title: string;
  contacts: Contact[];
  location: string;
  proposedTimes: string[];
  preferences?: {
    timePreference?: 'morning' | 'afternoon' | 'evening';
    durationType?: '30min' | '1hour' | '2hours' | 'custom';
    locationType?: 'coffee' | 'restaurant' | 'office' | 'virtual' | 'custom';
  };
}

interface ContactSearchResult {
  name: string;
  email: string;
  frequency: number;
  lastContact: Date;
  confidence: number;
  matchedName: string;
}

interface AssistantMessage {
  role: 'user' | 'assistant';
  content: string[];
}

export default function CreateMeetiniForm({ isOpen, onClose, onSuccess, initialPrompt }: CreateMeetiniFormProps) {
  const { data: session } = useSession();
  const [searchResults, setSearchResults] = useState<{ [key: string]: ContactSearchResult[] }>({});
  const [selectedContacts, setSelectedContacts] = useState<ContactSearchResult[]>([]);
  const [aiPrompt, setAiPrompt] = useState(initialPrompt || '');
  const [isSubmitting, setIsSubmitting] = useState(false);
  const [processingStatus, setProcessingStatus] = useState('');
  const [processingStage, setProcessingStage] = useState(0);
  const [processingSteps] = useState([
    { label: 'Analyzing your request', percentage: 20 },
    { label: 'Checking calendars', percentage: 40 },
    { label: 'Finding optimal times', percentage: 60 },
    { label: 'Creating invitation', percentage: 80 },
    { label: 'Sending invitations', percentage: 95 }
  ]);
  const [error, setError] = useState<string | null>(null);
  const [warningMessage, setWarningMessage] = useState<string | null>(null);
  const [unregisteredParticipants, setUnregisteredParticipants] = useState<string[]>([]);
  const [threadId, setThreadId] = useState<string | null>(null);
  const [messages, setMessages] = useState<AssistantMessage[]>([]);
  const [conflictInfo, setConflictInfo] = useState<any>(null);

  // Handle contact search when prompt changes
  useEffect(() => {
    const searchContacts = async () => {
      if (!aiPrompt) return;
      
      try {
        const response = await fetch(`/api/contacts/search?q=${encodeURIComponent(aiPrompt)}`);
        const data = await response.json();
        setSearchResults(data);
      } catch (err) {
        console.error('Failed to search contacts:', err);
      }
    };

    const debounceTimer = setTimeout(searchContacts, 300);
    return () => clearTimeout(debounceTimer);
  }, [aiPrompt]);

  const handleContactToggle = (contact: ContactSearchResult) => {
    setSelectedContacts(prev => {
      const exists = prev.find(c => c.email === contact.email);
      if (exists) {
        return prev.filter(c => c.email !== contact.email);
      } else {
        return [...prev, contact];
      }
    });
  };

  const handleCreateMeetini = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!aiPrompt.trim() || selectedContacts.length === 0) return;

    setIsSubmitting(true);
    setProcessingStatus('Analyzing your request...');
    setProcessingStage(0);
    setError(null);
    setWarningMessage(null);
    setUnregisteredParticipants([]);
    setConflictInfo(null);

    try {
      console.log('=== FRONTEND REQUEST ===');
      console.log('Sending to Assistant API:', {
        message: aiPrompt,
        participants: selectedContacts.map(c => c.email)
      });

      // Send to the AI-create endpoint
      const response = await fetch('/api/meetini/ai-create', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          message: aiPrompt,
          participants: selectedContacts.map(c => c.email)
        }),
      });

      if (!response.ok) {
        throw new Error('Failed to create Meetini');
      }

      setProcessingStatus('Checking calendars...');
      setProcessingStage(1);

      const data = await response.json();
      if (data.error) {
        throw new Error(data.error);
      }

      // If we have a warning about unregistered participants, show it but continue
      if (data.warning) {
        setWarningMessage(data.warning);
      }
      
      // If there are unregistered participants, track them
      if (data.unregisteredParticipants?.length) {
        setUnregisteredParticipants(data.unregisteredParticipants);
      }

      // Convert OpenAI messages to our format
      if (data.messages?.length > 0) {
        const messages = data.messages.map((msg: any) => ({
          role: msg.role,
          content: msg.content.map((c: any) => c.text.value)
        }));
        setMessages(messages.reverse()); // OpenAI returns newest first
      }

      // Use the suggested times from the Assistant
      if (!data.suggestedTimes?.length) {
        throw new Error('No suggested times available. Please try again.');
      }

      setProcessingStatus('Finding optimal times...');
      setProcessingStage(2);
      
      setTimeout(() => {
        setProcessingStatus('Creating invitation...');
        setProcessingStage(3);
      }, 1000);

      // Create the calendar event with the suggested time
      const createResponse = await fetch('/api/meetini/create', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          invite: {
            type: aiPrompt,
            participants: selectedContacts.map(c => ({ email: c.email })),
            suggestedTimes: data.suggestedTimes,
            createdBy: session?.user?.email
          }
        })
      });

      const responseData = await createResponse.json();

      if (!createResponse.ok) {
        // Handle specific error for conflicts
        if (createResponse.status === 409 && responseData.conflictType === 'existing_meetini') {
          setConflictInfo(responseData);
          throw new Error(responseData.message || responseData.error);
        }
        
        // Handle other errors
        throw new Error(responseData.error || 'Failed to create calendar event');
      }

      setProcessingStatus('Sending invitations...');
      setProcessingStage(4);

      setTimeout(() => {
        if (responseData.pendingConfirmation) {
          setProcessingStatus('✨ Success! Invitation sent pending participant confirmation.');
        } else {
          setProcessingStatus('✨ Success! Calendar invites sent.');
        }
        setProcessingStage(5);
        
        setTimeout(() => {
          onSuccess();
          onClose();
        }, 2000);
      }, 1000);

    } catch (error) {
      console.error('Failed to create Meetini:', error);
      setError(error instanceof Error ? error.message : 'An unknown error occurred');
    } finally {
      setIsSubmitting(false);
    }
  };

  const handleManageConflict = (action: 'cancel_existing' | 'try_different_time') => {
    if (action === 'cancel_existing') {
      // Here you would implement logic to cancel the existing meeting
      setProcessingStatus('Cancelling existing meetini...');
      setIsSubmitting(true);
      
      // Example implementation (would need actual API endpoint):
      // fetch(`/api/meetini/cancel/${conflictInfo.conflictDetails.meetingId}`)
      //   .then(() => handleCreateMeetini(...))
      
      // For now, just close the dialog
      setError('Feature coming soon: cancelling existing meetini');
      setConflictInfo(null);
      setIsSubmitting(false);
    } else {
      // Reset the form to try a different time
      setConflictInfo(null);
      setError(null);
      // You could suggest modifying the prompt here
    }
  };

  return (
    <div className="space-y-4">
      <form onSubmit={handleCreateMeetini} className="space-y-4">
        <div>
          <textarea
            value={aiPrompt}
            onChange={(e) => setAiPrompt(e.target.value)}
            placeholder="What kind of meeting would you like to schedule?"
            className="w-full p-3 border rounded-lg dark:bg-gray-800"
            rows={3}
            disabled={isSubmitting}
          />
        </div>

        <div className="space-y-2">
          <h3 className="font-medium">Selected Participants:</h3>
          <div className="flex flex-wrap gap-2">
            {selectedContacts.map((contact) => (
              <div
                key={contact.email}
                className="flex items-center gap-2 px-3 py-1 bg-green-100 dark:bg-green-900 rounded-full"
                onClick={() => handleContactToggle(contact)}
              >
                <span>{contact.name || contact.email}</span>
                <button type="button" className="text-sm">&times;</button>
              </div>
            ))}
          </div>
        </div>

        <div className="space-y-2">
          <h3 className="font-medium">Suggested Participants:</h3>
          <div className="space-y-2">
            {Object.entries(searchResults).map(([query, results]) => (
              <div key={query}>
                {results.map(contact => (
                  <div key={contact.email} onClick={() => handleContactToggle(contact)}
                       className={`p-2 rounded cursor-pointer ${
                         selectedContacts.some(c => c.email === contact.email)
                           ? 'bg-green-100 dark:bg-green-900'
                           : 'hover:bg-gray-100 dark:hover:bg-gray-800'
                       }`}>
                    {contact.name} ({contact.email})
                  </div>
                ))}
              </div>
            ))}
          </div>
        </div>

        {isSubmitting && (
          <div className="mt-4 p-4 bg-blue-50 dark:bg-blue-900/20 rounded-lg">
            <div className="flex items-center mb-2">
              <CircularProgress size={24} color="primary" />
              <span className="ml-3 font-medium">{processingStatus}</span>
            </div>
            <div className="w-full bg-gray-200 rounded-full h-2.5 mb-2 dark:bg-gray-700">
              <div 
                className="bg-blue-500 h-2.5 rounded-full transition-all duration-500 ease-in-out" 
                style={{ width: `${processingSteps[processingStage]?.percentage || 0}%` }}
              ></div>
            </div>
            <div className="text-xs text-gray-500 dark:text-gray-400">
              {processingStage === 5 ? 'Complete!' : 'Please wait while we process your request...'}
            </div>
          </div>
        )}

        {conflictInfo && (
          <div className="mt-4 p-4 bg-yellow-50 dark:bg-yellow-900/20 border border-yellow-200 dark:border-yellow-800 rounded-lg">
            <h3 className="font-medium text-yellow-800 dark:text-yellow-200 mb-2">⚠️ Scheduling Conflict</h3>
            <p className="mb-2">{conflictInfo.message}</p>
            <p className="mb-4 text-sm text-gray-600 dark:text-gray-300">{conflictInfo.suggestion}</p>
            <div className="flex gap-3">
              <button
                type="button"
                onClick={() => handleManageConflict('cancel_existing')}
                className="px-3 py-1.5 bg-yellow-500 text-white rounded text-sm"
              >
                Cancel Existing Meeting
              </button>
              <button
                type="button"
                onClick={() => handleManageConflict('try_different_time')}
                className="px-3 py-1.5 bg-gray-200 dark:bg-gray-700 text-gray-800 dark:text-gray-200 rounded text-sm"
              >
                Try Different Time
              </button>
            </div>
          </div>
        )}

        {warningMessage && !error && !conflictInfo && (
          <div className="mt-4 p-4 bg-amber-50 dark:bg-amber-900/20 border border-amber-200 dark:border-amber-800 rounded-lg">
            <h3 className="font-medium text-amber-800 dark:text-amber-200 mb-2">⚠️ Limited Calendar Access</h3>
            <p className="mb-2">{warningMessage}</p>
            {unregisteredParticipants.length > 0 && (
              <div className="mb-3">
                <p className="text-sm font-medium mb-1">Participants without calendar access:</p>
                <ul className="text-sm list-disc pl-5">
                  {unregisteredParticipants.map(email => (
                    <li key={email}>{email}</li>
                  ))}
                </ul>
              </div>
            )}
            <p className="text-sm text-gray-600 dark:text-gray-300">
              Suggested times are based on standard availability and may not reflect actual schedules.
              Consider confirming availability separately with these participants.
            </p>
          </div>
        )}

        {error && !conflictInfo && (
          <Alert severity="error" className="mt-4">
            {error}
          </Alert>
        )}

        <div className="flex justify-end gap-4">
          <button
            type="button"
            onClick={onClose}
            className="px-4 py-2 text-gray-600 dark:text-gray-300"
            disabled={isSubmitting}
          >
            Cancel
          </button>
          <button
            type="submit"
            className="px-4 py-2 bg-green-500 text-white rounded-lg disabled:opacity-50"
            disabled={isSubmitting || !aiPrompt.trim() || selectedContacts.length === 0}
          >
            {isSubmitting ? (
              <span>Processing...</span>
            ) : (
              'Create Meetini'
            )}
          </button>
        </div>
      </form>

      {messages.length > 0 && (
        <div className="mt-4 p-4 bg-gray-50 dark:bg-gray-800 rounded-lg">
          {messages.map((msg, i) => (
            <div key={i} className={`mb-2 ${msg.role === 'assistant' ? 'text-blue-600' : ''}`}>
              {msg.content.map((c, j) => (
                <p key={j}>{c}</p>
              ))}
            </div>
          ))}
        </div>
      )}
    </div>
  );
}